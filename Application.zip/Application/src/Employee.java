
public class Employee extends javax.swing.JInternalFrame {


    public Employee() {
        initComponents();
        this.setOpaque(false);
    
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        employeeWorking1 = new Windows.EmployeeWorking();

        getContentPane().add(employeeWorking1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private Windows.EmployeeWorking employeeWorking1;
    // End of variables declaration//GEN-END:variables
}
