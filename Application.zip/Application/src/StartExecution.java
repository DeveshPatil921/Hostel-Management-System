
public class StartExecution {
    
    public static void main(String[] args) {

        // Now time to start the Software
        LogineForm GPAHostel = new LogineForm();
        GPAHostel.setVisible(true);
    }
}
